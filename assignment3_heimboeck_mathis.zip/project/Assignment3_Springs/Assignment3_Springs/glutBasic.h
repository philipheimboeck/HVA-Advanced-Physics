/** 
 * Create a new window
 */
void createWindow(const char* title, int width, int height);